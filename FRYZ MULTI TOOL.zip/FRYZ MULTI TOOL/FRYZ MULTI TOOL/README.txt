Thanks For Buying

To use you need WINRAR and a brain c;

Right click the fryz.rar file and press "open with winrar"

drag the folder to your desktop and youre done!

enjoy!